# liquidrocketpy TODO

- team roster
- team previous results 
- player info
- tournament info
- upcoming tournaments

## Contribution

 If anyone wants to help that would be fun ya know